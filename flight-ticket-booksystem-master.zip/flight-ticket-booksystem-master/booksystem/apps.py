from django.apps import AppConfig


class BooksystemConfig(AppConfig):
    name = 'booksystem'
